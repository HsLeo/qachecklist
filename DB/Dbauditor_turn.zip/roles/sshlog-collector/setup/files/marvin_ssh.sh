DATE=`date --rfc-3339=ns`
TT=`date -d "$DATE" +%s.%N`
HOSTNAME=`hostname`
SSH_CONNECTION=$SSH_CONNECTION
FILEPATH=/var/lib/marvin/sshlogin/monitor_$USER.log
R_FILEPATH=/var/lib/marvin/sshlogin/monitor_$USER.1.log
LIMIT=10485760

DIR=$(dirname $FILEPATH )
LD_LIBRARY_PATH=""

if [ "$ASCIINEMA" == "1" ] || [ "x$SSH_CONNECTION" == "x" ]; then
    return
fi
if [ -d "$DIR" ]; then
    echo "[$DATE][$SSH_CONNECTION][$USER][$HOSTNAME][$MARVIN_HASH_ID]" >> $FILEPATH
else
    return
fi

SIZE=$(stat -c%s $FILEPATH 2>/dev/null)
if [ "$?" != "0" ]; then
    return
fi
if [ $SIZE -gt $LIMIT ]; then
    mv $FILEPATH $R_FILEPATH 2>/dev/null
fi
