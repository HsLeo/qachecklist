#!/bin/bash
_args=($@)
_base=$(basename $0)

# constants for script internal usage
_cdnwatcher="cdnwatcher"
_fluentbit="fluentbit"

# default values
_md5_name=""
_watch_path=""
_watch_urls=""
_fluentd_addr=""
_fluentd_port=""
_debug=false
_help=false
_set_watch=false
_got_url=false
_set_addr=false
_set_port=false
_set_target=false
_to_restart=false
_to_start=false
_to_stop=false
_target="${_cdnwatcher}"
_is_cdnwatcher=false
_is_fluentbit=false

# prefix
_tmp_home_prefix="/opt/cdnwatcher"

# constants for deployment and temp files
CDNWATCHER_ID=".container-id"
FLUENTBIT_ID=".fluentbit-id"
PID=".pid"
LOGPATH=".logpath"
CDNWATCHER=dockerhub.pentium.network/cdnwatcher/cdnwatcher:v0.0.4
FLUENTBIT=dockerhub.pentium.network/cdnwatcher/fluent-bit:1.1.2
CDNWATCHER_NAME="PN-cdnwatcher-"
FLUENTBIT_NAME="PN-cdnwatcher-fluent-bit"

# useage prints the usage of this script
function usage() {
  echo 
  echo "Usage: $0 [flags]"
  echo "  flags:"
  echo "    --fluentd-addr: IP addr of the target Fluentd, REQUIRED if to start or restart \"fluentbit\""
  echo "    --fluentd-port: port of the target Fluentd, REQUIRED if to start or restart \"fluentbit\""
  echo "    --help, -h    : show this help message"
  echo "    --restart, -r : restart the daemon"
  echo "    --start       : start the daemon"
  echo "    --stop        : stop the daemon"
  echo "    --target, -t  : the target to manipulate, available options: [${_cdnwatcher}|${_fluentbit}], DEFAULT: \"${_cdnwatcher}\""
  echo "    --watch, -w   : the absolute path to the directory to watch, REQUIRED if target is cdnwatcher"
  echo "    --url, -u     : the URLs mapping to the directory given by [--watch], multiple URLs are separated by \",\", REQUIRED if to start or restart \"cdnwatcher\""
}

# error prints error msg
function error() {
  echo 1>&2
  echo "------" 1>&2
  echo "Fatal error:" 1>&2
  echo "  $@" 1>&2
  echo  1>&2
  usage 1>&2
  exit 1
}

# check_binary checks if the required binaries are available
function check_binary () {
  local tmp=`which docker`
  if [ "x${tmp}" == "x" ]; then
    error "docker is not available, please contact you system administrator"
  fi
  tmp=$(docker version 2>&1 | grep "permission denied")
  if [ "x${tmp}" != "x" ]; then
    error "the user have no permission for docker command, please contact your system administrator"
  fi
  tmp=`which grep`
  if [ "x${tmp}" == "x" ]; then
    error "grep is not available, please contact your system administrator"
  fi
  tmp=`which md5sum`
  if [ "x${tmp}" == "x" ]; then
    error "md5sum is not available, please contact your system administrator"
  fi
  tmp=`which awk`
  if [ "x${tmp}" == "x" ]; then
    error "awk is not available, please contact your system administrator"
  fi
  tmp=`which egrep`
  if [ "x${tmp}" == "x" ]; then
    error "egrep is not available, please contact your system administrator"
  fi
}

# check_url checks if the given url is valid
function check_url() {
  local ary=($(echo $1 | sed 's/,/ /g'))
  local item=""
  local is_valid=true
  local rexp='^https?://'
  for item in ${ary[@]}; do
    if ! [[ ${item} =~ ${rexp} ]]; then
      is_valid=false
      break
    fi
  done
  if ${is_valid}; then
    echo "true"
  else
    echo "false"
  fi
}

# is_integer checks if the input is an integer
function is_integer() {
  local rexp='^[0-9]+$'
  if ! [[ ${1} =~ ${rexp} ]]; then
    echo "false"
    return
  fi
  echo "true"
}

# is_ip checks if the input is a valid ipv4 ip
function is_ip() {
  local tokens=($(echo ${1} | sed 's/\./ /g'))
  if [ ${#tokens[@]} -ne 4 ]; then
    echo "false"
    return
  fi
  local item=
  for item in ${tokens[@]}; do
    if [ "x$(is_integer ${item})" != "xtrue" ]; then
      echo "false"
      return
    fi
    if [ ${item} -gt 255 ]; then
      echo "false"
      return
    fi
  done
  echo "true"
  return
}

# is_port check if the input is a valid port number
function is_port() {
  if [ "x$(is_integer ${1})" != "xtrue" ]; then
    echo "false"
    return
  fi
  if [ ${1} -eq 0 ] || [ ${1} -gt 65535 ]; then
    echo "false"
    return
  fi
  echo "true"
}

# to_lower converts the input string to lowercase
function to_lower() {
  echo $@ | tr [:upper:] [:lower:]
}

# check_target checks if the target string is valid as the target of this script
function check_target() {
  case ${1} in
    "${_cdnwatcher}")
      echo "true"
      ;;
    "${_fluentbit}")
      echo "true"
      ;;
    *)
      echo "false"
  esac
}

# check_path checks if the target path is valid
function check_path() {
  local rexp="^${_tmp_home_prefix}/"
  if [[ "${1}" =~ ${rexp} ]]; then
    error "cannot watch sub-directory of ${_tmp_home_prefix}, aborting..."
  fi
  local stat=$(stat ${1} 2>&1)
  rexp='^stat: cannot stat'
  if [[ "${_stat}" =~ ${rexp} ]]; then
    error "failed to access target directory (${_watch_path})"
  fi
  echo "true"
}

# parse_flag parses the input flags
function parse_flag() {
  local args_len=${#_args[@]}
  local i=0
  for((i = 0; i < ${args_len}; i++)); do
    local arg=${_args[${i}]}
    case "x${arg}" in
      "x-d")
        _debug=true
        ;;
      "x--fluentd-addr")
        if ${_set_addr}; then
          error "duplicated call of [--fluentd-addr], all flags with input parameter can can only be called once"
        fi
        i=$((i + 1))
        local next=${_args[${i}]}
        if [ "x${next}" != "x" ]; then
          _fluentd_addr=${next}
        fi
        _set_addr=true
        ;;
      "x--fluentd-port")
        if ${_set_port}; then
          error "duplicated call of [--fluentd-port], all flags with input parameter can can only be called once"
        fi
        i=$((i + 1))
        local next=${_args[${i}]}
        if [ "x$(is_port ${next})" != "xtrue" ]; then
          error "please input valid IP addr for [--fluentd-addr]"
        fi
        if [ "x${next}" != "x" ]; then
          _fluentd_port=${next}
        fi
        _set_port=true
        ;;
      "x-h")
        _help=true
        ;;
      "x--help")
        _help=true
        ;;
      "x-r")
        if ${_to_stop} || ${_to_start}; then
          error "[--restart], [--start], and [--stop] cannot be called at the same time, please check your input"
        fi
        _to_restart=true
        ;;
      "x--restart")
        if ${_to_stop} || ${_to_start}; then
          error "[--restart], [--start], and [--stop] cannot be called at the same time, please check your input"
        fi
        _to_restart=true
        ;;
      "x--start")
        if ${_to_stop} || ${_to_restart}; then
          error "[--restart], [--start], and [--stop] cannot be called at the same time, please check your input"
        fi
        _to_start=true
        ;;
      "x--stop")
        if ${_to_start} || ${_to_restart}; then
          error "[--restart], [--start], and [--stop] cannot be called at the same time, please check your input"
        fi
        _to_stop=true
        ;;
      "x-t")
        if ${_set_target}; then
          error "duplicated call of [--target|-t], all flags with input parameter can can only be called once"
        fi
        i=$((i + 1))
        local next=$(to_lower ${_args[${i}]})
        if [ "x$(check_target ${next})" != "xtrue" ]; then
          error "invalid input parameter for [--target|-t], available options are [${_cdnwatcher}|${_fluentbit}]"
        fi
        _target=${next}
        ;;
      "x--target")
        if ${_set_target}; then
          error "duplicated call of [--target|-t], all flags with input parameter can can only be called once"
        fi
        i=$((i + 1))
        local next=$(to_lower ${_args[${i}]})
        if [ "x$(check_target ${next})" != "xtrue" ]; then
          error "invalid input parameter for [--target|-t], available options are [${_cdnwatcher}|${_fluentbit}]"
        fi
        _target=${next}
        ;;
      "x-w")
        if ${_set_watch}; then
          error "duplicated call of [--watch|-w], all flags with input parameter can can only be called once"
        fi
        i=$((i + 1))
        local next=${_args[${i}]}
        if [ "x${next}" != "x" ] && [ "x$(check_path ${next})" = "xtrue" ]; then
          _watch_path=${next}
        fi
        if [ "x$(echo ${_watch_path: -1})" != "x/" ]; then
          _watch_path=${_watch_path}/
        fi
        _set_watch=true
        ;;
      "x--watch")
        if ${_set_watch}; then
          error "duplicated call of [--watch|-w], all flags with input parameter can can only be called once"
        fi
        i=$((i + 1))
        local next=${_args[${i}]}
        if [ "x${next}" != "x" ] && [ "x$(check_path ${next})" = "xtrue" ]; then
          _watch_path=${next}
        fi
        if [ "x$(echo ${_watch_path: -1})" != "x/" ]; then
          _watch_path=${_watch_path}/
        fi
        _set_watch=true
        ;;
      "x-u")
        if ${_got_url}; then
          error "duplicated call of [--url,u], all flags with input parameter can only be called once"
        fi
        i=$((i + 1))
        local next=${_args[${i}]}
        local is_url=$(check_url ${next})
        if [ "x${is_url}" != "xtrue" ]; then
          error "got invalid URL string: ${next}"
        fi
        if [ "x${next}" != "x" ]; then
          _watch_urls=${next}
        fi
        _got_url=true
        ;;
      "x--url")
        if ${_got_url}; then
          error "duplicated call of [--url,u], all flags with input parameter can only be called once"
        fi
        i=$((i + 1))
        local next=${_args[${i}]}
        local is_url=$(check_url ${next})
        if [ "x${is_url}" != "xtrue" ]; then
          error "got invalid URL string: ${next}"
        fi
        if [ "x${next}" != "x" ]; then
          _watch_urls=${next}
        fi
        _got_url=true
        ;;
      *)
        error "got invalid flag: [${_arg}]"
        ;;
    esac
  done
  if ${_debug}; then
    echo "tmp directory created: ${_tmp_root}"
  fi
}

# validate_flags validates if the input flags are valid
function validate_flags() {
  case ${_target} in
    "cdnwatcher")
      _is_cdnwatcher=true
      _is_fluentbit=false
      ;;
    "fluentbit")
      _is_cdnwatcher=false
      _is_fluentbit=true
      ;;
    *)
      error "invalid input parameter for [--target|-t], available options are [${_cdnwatcher}|${_fluentbit}]"
      ;;
  esac
  if ${_is_cdnwatcher} && ${_is_fluentbit}; then
    error "can only have one target, either cdnwatcher or fluentbit"
  fi
  if ! ${_is_cdnwatcher} && ! ${_is_fluentbit}; then
    error "must have one target, either cdnwatcher or fluentbit"
  fi
  if ! ${_help} && ! ${_to_restart} && ! ${_to_start} && ! ${_to_stop}; then
    error "exactly one operation is required [--help|-h|--restart|--start|--stop]"
  fi
  if ${_help}; then
    return
  fi
  if ${_is_cdnwatcher} && [ "x${_watch_path}" == "x" ]; then
    error "[--watch|-w] is required, please input the absolute path to the directory to watch"
  fi
  local rexp='^/+'
  if ${_is_cdnwatcher} && ! [[ ${_watch_path} =~ ${rexp} ]]; then
    error "[${_watch_path}] is not a valid absolute path"
  fi
  if ${_is_cdnwatcher} && ${_to_start} && [ "x${_watch_urls}" == "x" ]; then
    error "[--url|-u] is required, please input the urls corresponding to the directory provided by [--watch|-w]"
  fi
  if ${_is_fluentbit} && ${_to_start} && [ "x${_fluentd_addr}" == "x" ]; then
    error "[--fluentd-addr] is required, please input the IP of the Fluentd"
  fi
  if ${_is_fluentbit} && ${_to_start} && [ "x${_fluentd_port}" == "x" ]; then
    error "[--fluentd-port] is required, please input the port of the Fluentd"
  fi
}

# check_status checks if the given container is running
function check_status() {
  if [ "x${1}" == "x" ]; then
    echo "false"
    return
  fi
  local status=$(docker inspect ${1} 2>&1 | grep "\"Status\":" | awk '{print $NF}' | sed 's/"//g' | sed 's/,//g')
  if [ "x${status}" != "xrunning" ]; then
    echo "false"
    return
  fi
  echo "true"
  return
}

# start_fluentbit starts the fluentbit
function start_fluentbit() {
  local fname=${FLUENTBIT_NAME}
  local cid=$(docker run --ulimit nofile=1048576:1048576 --log-driver json-file --log-opt max-size=10m --log-opt max-file=2 -d --name ${fname} --restart=always -v ${_tmp_home_prefix}:/var/lib/cdnwatcher:z -e FLUENTD_ADDR=${_fluentd_addr} -e FLUENTD_PORT=${_fluentd_port} ${FLUENTBIT})
  
  local rexp="^[0-9a-z]{64}$"
  if [[ "${cid}" =~ ${rexp} ]]; then
    echo "fluent-bit (${fname}, ${cid}) is now started"
  else
    echo "failed to start cdnwatcher: ${cid}"
    exit 1
  fi
  return
}

# start_fluentbit starts the fluentbit daemon
function start_fluentbit_daemon() {
  local fname=${FLUENTBIT_NAME}
  local running=true
  if [ "x${fname}" == "x" ] || [ "x$(check_status ${fname})" != "xtrue" ]; then
    running=false
  fi

  if ${running}; then
    echo "fluentbit (${fname}) is running, abort"
    return
  fi

  # start fluentbit
  start_fluentbit
}

# start_cdnwatcher starts the cdnwatcher
function start_cdnwatcher() {
  local cname=${1}
  local cid=""
  if ${_debug}; then
    cid=$(docker run --ulimit nofile=1048576:1048576 --log-driver json-file --log-opt max-size=10m --log-opt max-file=2 -d --name ${cname} --restart=always -h `hostname` -v ${_tmp_home}:/var/lib/cdnwatcher:z -v ${_watch_path}:/var/lib/static:z -e CDNHOSTPATH=${_watch_path} -e WATCHPATH=/var/lib/static,${_watch_urls} -e DEBUG="true" ${CDNWATCHER}-debug)
  else
    cid=$(docker run --ulimit nofile=1048576:1048576 --log-driver json-file --log-opt max-size=10m --log-opt max-file=2 -d --name ${cname} --restart=always -h `hostname` -v ${_watch_path}:/var/lib/static:z -v ${_tmp_home}:/var/lib/cdnwatcher:z -e CDNHOSTPATH=${_watch_path} -e WATCHPATH=/var/lib/static,${_watch_urls} ${CDNWATCHER})
  fi

  local rexp="^[0-9a-z]{64}$"
  if [[ "${cid}" =~ ${rexp} ]]; then
    echo "cdnwatcher (${cname}, ${cid}) is now started"
  else
    echo "failed to start cdnwatcher: ${cid}"
    exit 1
  fi
  return
}

# start_cdnwatcher_daemon starts the file watching daemon
function start_cdnwatcher_daemon() {
  # check if the services are running
  local cname=${CDNWATCHER_NAME}${_md5_name}
  local running=true
  if [ "x${_md5_name}" == "x" ] || [ "x$(check_status ${cname})" != "xtrue" ]; then
    running=false
  fi

  # if running, return
  if ${running}; then
    echo "cdnwatcher (${cname}) is running, abort"
    return
  fi

  # start cdnwatcher
  start_cdnwatcher ${cname}
  return
}

# stop_fluentbit_daemon stops fluentbit daemon
function stop_fluentbit_daemon() {
  local cdnwatcher_list=($(docker ps  | egrep "\<cdnwatcher-[a-z0-9]{32}\>" | awk '{print $1}'))
  if [ ${#cdnwatcher_list[@]} -gt 0 ]; then
    echo "there are still ${#cdnwatcher_list[@]} cdnwatchers, aborting..."
    return
  fi
  local fname=${FLUENTBIT_NAME}
  local running=true
  if [ "x${fname}" == "x" ] || [ "x$(check_status ${fname})" != "xtrue" ]; then
    running=false
  fi

  # not running, return
  if ! ${running}; then
    _discard=$(docker rm -f ${fname})
    _discard=$(docker rmi ${FLUENTBIT})
    return
  fi

  # stop fluentbit
  local _discard=$(docker update --restart=no ${fname})
  _discard=$(docker kill ${fname})
  _discard=$(docker rm -f ${fname})
  _discard=$(docker rmi ${FLUENTBIT})
}

# stop_cdnwatcher_daemon stops cdnwatcher daemon
function stop_cdnwatcher_daemon() {
  # check if the services are running
  local cname=${CDNWATCHER_NAME}${_md5_name}
  local running=true
  if [ "x${_md5_name}" == "x" ] || [ "x$(check_status ${cname})" != "xtrue" ]; then
    running=false
  fi

  # not running, return
  if ! ${running}; then
    _discard=$(docker rm -f ${cname})
    if ${_debug}; then
      _discard=$(docker rmi ${CDNWATCHER}-debug)
    else
      _discard=$(docker rmi ${CDNWATCHER})
    fi
    return
  fi

  # stop cdnwatcher
  local _discard=$(docker update --restart=no ${cname})
  _discard=$(docker kill ${cname})
  _discard=$(docker rm -f ${cname})
  if ${_debug}; then
    _discard=$(docker rmi ${CDNWATCHER}-debug)
  else
    _discard=$(docker rmi ${CDNWATCHER})
  fi
}

function main() {
  check_binary
  parse_flag
  validate_flags
  if ${_help}; then
    usage
    exit 0
  fi

  if ${_is_cdnwatcher}; then
    # make temp dir according to the given directory
    _md5_name=$(echo ${_watch_path} | md5sum | awk '{print $1}')
    _tmp_home=${_tmp_home_prefix}/${_md5_name}
    mkdir -p ${_tmp_home}
    echo "the temp directory for ${_watch_path} is ${_tmp_home}"
  fi
  if ${_is_cdnwatcher} && ${_to_start}; then
    start_cdnwatcher_daemon
    exit 0
  fi
  if ${_is_cdnwatcher} && ${_to_stop}; then
    stop_cdnwatcher_daemon
    exit 0
  fi
  if ${_is_cdnwatcher} && ${_to_restart}; then
    stop_cdnwatcher_daemon
    sleep 1
    start_cdnwatcher_daemon
    exit 0
  fi
  if ${_is_fluentbit} && ${_to_start}; then
    start_fluentbit_daemon
    exit 0
  fi
  if ${_is_fluentbit} && ${_to_stop}; then
    stop_fluentbit_daemon
    exit 0
  fi
  if ${_is_fluentbit} && ${_to_restart}; then
    stop_fluentbit_daemon
    sleep 1
    start_fluentbit_daemon
    exit 0
  fi
}

if [ $# -lt 1 ]; then
  error "no flag is provided"
  exit 1
fi

main
