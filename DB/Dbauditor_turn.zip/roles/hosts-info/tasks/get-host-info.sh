#!/usr/bin/env bash

#OS:
varOS=$(uname)
varReleaseFile=/etc/os-release #CentOS7.x and debian/uuntu store os release info in /etc/os-release ...
if [ ! -f $varReleaseFile ]; then
    varReleaseFile=/etc/redhat-release #...but not CentOS6.x
fi
varDistro=$(cat $varReleaseFile | grep PRETTY_NAME 2>/dev/null)
varDistro=${varDistro/PRETTY_NAME*=/}
varDistro=${varDistro/'"'/}
varDistro=${varDistro/'"'/}

#Architecture:
varArchitecture=$(uname -i)

#CPU info:
varCPUCount=$(cat /proc/cpuinfo | grep processor | wc -l)
varCoreCount=$(cat /proc/cpuinfo | grep 'core id' | wc -l)
varCPUmodel=$(cat /proc/cpuinfo | grep 'model name' | uniq)
varCPUmodel=${varCPUmodel/model name*:/}
varCPUmodel=$(echo "$varCPUmodel" | xargs)

#Motherboard:
varMbManufacturer=$(sudo dmidecode -t 2 | grep Manufacturer)
varMbManufacturer=${varMbManufacturer/Manufacturer*:/}
varMbManufacturer=$(echo "$varMbManufacturer" | xargs)

varMbProductName=$(sudo dmidecode -t 2 | grep 'Product Name')
varMbProductName=${varMbProductName/Product Name*:/}
varMbProductName=$(echo "$varMbProductName" | xargs)

varMbSerialNo=$(sudo dmidecode -t 2 | grep 'Serial Number')
varMbSerialNo=${varMbSerialNo/Serial Number*:/}
varMbSerialNo=$(echo "$varMbSerialNo" | xargs)

#Memory:
varTotalPhysicalMem=$(echo $(($(getconf _PHYS_PAGES) * $(getconf PAGE_SIZE) / (1024 * 1024))))
varTotalVirtualMem=$(echo $(($(getconf _AVPHYS_PAGES) * $(getconf PAGE_SIZE) / (1024 * 1024))))

#Storage:
varDiskCount=$(lsblk -d | grep disk | wc -l)

#NIC(s)
varNICCount=$(lspci | grep -i net | wc -l)

#Disk report:
diskInfo="["
firstRun=true
while read -r line; do
   if [ "$firstRun" = false ] ; then
       diskInfo="$diskInfo,"
   else
       firstRun=false
   fi
   sua=`grep 'nodev' '/proc/filesystems' | sed -e 's/nodev\t/-x /' | xargs df --local --total | tail -n 1`
   disk_size=`echo $sua | awk '{printf "%d",$2/1024;}'`;
   vDevice=$(echo $line | awk '{print $1}' 2>/dev/null)
   vDevice="/dev/$vDevice"
   diskInfo="$diskInfo{\"path\":\"$vDevice\","
   vSize=$(echo $line | awk ‘{print $4}’ 2>/dev/null)
   diskInfo="$diskInfo\"size\":\"$disk_size\"}"
#    vSize=$(echo $(($(sudo blockdev --getsize64 $vDevice) / (1024))))
#    diskInfo="$diskInfo\"sizeMb\":\"$vSize\"}"
done < <(lsblk -d | grep disk 2>/dev/null)
diskInfo="$diskInfo]"
# echo $diskInfo


#NIC(s)
nicInfo="["
firstRun=true
while read -r line; do
   if [ "$firstRun" = false ] ; then
       nicInfo="$nicInfo,"
   else
       firstRun=false
   fi
   varNIC=${line/??:*:/}
   varNIC=$(echo "$varNIC" | xargs 2>/dev/null)
   nicInfo="$nicInfo\"$varNIC\""
done < <(lspci | grep -i net 2>/dev/null)
nicInfo="$nicInfo]"
# echo $nicInfo



#Report:
echo -n "{\"os\":\"$varOS\", \
\"osDistro\":\"$varDistro\", \
\"arch\":\"$varArchitecture\", \
\"cpu\":\"$varCPUmodel\", \
\"coreCount\":\"$varCoreCount\", \
\"memPhysical\":\"$varTotalPhysicalMem\", \
\"memVirtual\":\"$varTotalVirtualMem\", \
\"mbManufacturer\":\"$varMbManufacturer\", \
\"mbName\":\"$varMbProductName\", \
\"mbSerialNo\":\"$varMbSerialNo\", \
\"diskcount\":\"$varDiskCount\", \
\"hdds\":$diskInfo, \
\"ethernets\":$nicInfo \
}"